﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MTE
{
    [Serializable]
    public class GrassQuad
    {
        [SerializeField]
        private Material material;
        [SerializeField]
        private Vector3 position;
        [SerializeField]
        private float width;
        [SerializeField]
        private float height;

        public Material Material
        {
            get { return this.material; }
        }

        public Vector3 Position
        {
            get { return this.position; }
            set { this.position = value; }
        }

        public float Width
        {
            get { return this.width; }
        }

        public float Height
        {
            get { return this.height; }
        }

        public void Init(Material material, Vector3 position, float width, float height)
        {
            this.material = material;
            this.position = position;
            this.width = width;
            this.height = height;
        }
    }
}
