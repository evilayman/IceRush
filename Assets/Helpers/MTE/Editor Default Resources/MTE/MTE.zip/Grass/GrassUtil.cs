using System.Collections.Generic;
using UnityEngine;

namespace MTE
{
    public class GrassUtil
    {
        #region grass triple-quad

        private static Vector3 Rotate2D(Vector3 v, float angle)
        {
            float x = v.x, y = v.z;

            float len = (new Vector2(x, y)).magnitude;
            if (Mathf.Approximately(0f, len))
                return v;

            float a;
            if (!Mathf.Approximately(0f, x))
            {
                a = Mathf.Acos(x / len);
            }
            else
            {
                a = Mathf.Asin(y / len);
            }
            x = Mathf.Cos(a + angle) * len;
            y = Mathf.Sin(a + angle) * len;

            v.Set(x, v.y, y);
            return v;
        }

        static Vector3[] GenerateSingleGrassVertices(float width, float height, Quaternion rotation)
        {
            var vSliceVertex = new Vector3[]{
                new Vector3(-0.5f*width,0,0),
                new Vector3(0.5f*width,0,0),
                new Vector3(-0.5f*width, height, 0),
                new Vector3(0.5f*width, height, 0)};
            var holeSize = 0.1f;
            //vertexes
            var vertexes = new List<Vector3>(4 * 3);
            vertexes.AddRange(vSliceVertex);
            vertexes.AddRange(vSliceVertex);
            vertexes.AddRange(vSliceVertex);
            //first slice
            var v1 = new Vector3(0f, 0f, -1.0f) * holeSize;
            vertexes[0] += v1 * width;
            vertexes[1] += v1 * width;
            vertexes[2] += v1 * width;
            vertexes[3] += v1 * width;
            //second slice
            var v2 = new Vector3(-0.866254f, 0f, 0.5f) * holeSize;
            vertexes[4] = Rotate2D(vertexes[4], Mathf.PI / 3);
            vertexes[5] = Rotate2D(vertexes[5], Mathf.PI / 3);
            vertexes[6] = Rotate2D(vertexes[6], Mathf.PI / 3);
            vertexes[7] = Rotate2D(vertexes[7], Mathf.PI / 3);
            vertexes[4] += v2 * width;
            vertexes[5] += v2 * width;
            vertexes[6] += v2 * width;
            vertexes[7] += v2 * width;
            //third slice
            var v3 = new Vector3(0.866254f, 0f, 0.5f) * holeSize;
            vertexes[8] = Rotate2D(vertexes[8], Mathf.PI / 3 * 2);
            vertexes[9] = Rotate2D(vertexes[9], Mathf.PI / 3 * 2);
            vertexes[10] = Rotate2D(vertexes[10], Mathf.PI / 3 * 2);
            vertexes[11] = Rotate2D(vertexes[11], Mathf.PI / 3 * 2);
            vertexes[8] += v3 * width;
            vertexes[9] += v3 * width;
            vertexes[10] += v3 * width;
            vertexes[11] += v3 * width;

            // NOT build rotation into vertexes
            //for (var i = 0; i < vertexes.Count; ++i)
            //{
            //    vertexes[i] = rotation * vertexes[i];
            //}
            return vertexes.ToArray();
        }

        static Vector2[] GenerateSingleGrassUVs()
        {
            var vSliceUV = new Vector2[]{
                new Vector2(0,0),
                new Vector2(1,0),
                new Vector2(0,1),
                new Vector2(1,1)};
            var uvs = new List<Vector2>(4 * 3);
            uvs.AddRange(vSliceUV);
            uvs.AddRange(vSliceUV);
            uvs.AddRange(vSliceUV);
            return uvs.ToArray();
        }

        static int[] GenerateSingleGrassTriangles()
        {
            var vSliceIndex = new int[]
            {
                3, 1, 0, 2, 3, 0,
                4+0, 4+1, 4+3, 4+0, 4+3, 4+2,
                8+3, 8+1, 8+0, 8+2, 8+3, 8+0,
            };
            return vSliceIndex;
        }

        public static GameObject GenerateGrassInstance(Vector3 position, Quaternion rotation, float width, float height, Material material)
        {
            GameObject obj = new GameObject("GrassInstance");
            var meshFilter = obj.AddComponent<MeshFilter>();
            var meshRenderer = obj.AddComponent<MeshRenderer>();

            Mesh mesh = new Mesh();
            mesh.vertices = GenerateSingleGrassVertices(width, height, rotation);
            mesh.triangles = GenerateSingleGrassTriangles();
            mesh.uv = GenerateSingleGrassUVs();

            meshRenderer.sharedMaterial = material;
            meshFilter.sharedMesh = mesh;

            obj.transform.position = position;
            obj.transform.rotation = rotation;

            return obj;
        }

        #endregion  

        #region grass quad

        public static GameObject GenerateGrassQuad(Vector3 position, float width, float height, Material material)
        {
            GameObject obj = new GameObject("GrassQuad");
            var meshFilter = obj.AddComponent<MeshFilter>();
            var meshRenderer = obj.AddComponent<MeshRenderer>();

            Mesh quad = new Mesh();
            var vQuadVertex = new Vector3[]{
                new Vector3(-0.5f*width,0,0),
                new Vector3(0.5f*width,0,0),
                new Vector3(-0.5f*width, height, 0),
                new Vector3(0.5f*width, height, 0)};
            var vQuadUV = new Vector2[]{
                new Vector2(0,0),
                new Vector2(1,0),
                new Vector2(0,1),
                new Vector2(1,1)};
            var vQuadIndex = new int[]
            {
                3, 1, 0, 2, 3, 0,
            };

            quad.vertices = vQuadVertex;
            quad.triangles = vQuadIndex;
            quad.uv = vQuadUV;

            meshRenderer.sharedMaterial = material;
            meshFilter.sharedMesh = quad;

            obj.transform.position = position;
            obj.transform.rotation = Quaternion.identity;

            return obj;
        }

        #endregion

    }
}